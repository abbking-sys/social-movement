
If you use these data, you should cite this paper:

V. Krebs, "Mapping networks of terrorist cells." Connections 24, 43-52 (2002).

http://insna.org/PDF/Connections/v24/2001_I-3-7.pdf
